export default function Contact() {
   return (
      <div className="contact">
         <h2 className="contact__us">Contact</h2>
         <p className="contact__email">Email us at: example@mail.com</p>
      </div>
   );
}