export default function NotFound() {
   return (
      <div className="error">
         <h2 className="error__title">404 - Page Not Found</h2>
      </div>
   );
}