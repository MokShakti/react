import React from 'react';

export default function About() {
   return (
      <div className='about'>
         <h2 className='about__us'>About Us</h2>
         <p className='about__info'>Information about our beauty shop.</p>
      </div>
   );
}