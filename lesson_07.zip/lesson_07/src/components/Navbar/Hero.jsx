const Hero = () => {
   return (
      <div className="hero">
         <h1 className="hero__title">Chanel</h1>
         <p className="hero_text">Find something you like</p>
      </div>
   );
};

export default Hero;