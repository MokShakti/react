import React from 'react';

const Footer = () => {
   return (
      <footer>
         <p>Copyright Viktoriia Filipovych</p>
      </footer>
   );
};

export default Footer;