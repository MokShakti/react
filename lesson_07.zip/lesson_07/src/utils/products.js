export const products = [
   {
      id: '1',
      name: 'ROUGE ALLURE LEXTRAIT',
      price: 260,
      category: 'lipsticks',
      image: "ROUGE-ALLURE-L-EXTRAIT.avif"
   },
   {
      id: '2',
      name: 'ROUGE ALLURE VELVET',
      price: 247,
      category: 'lipsticks',
      image: "ROUGE-ALLURE-VELVET.avif"
   },
   {
      id: '3',
      name: 'ROUGE COCO FLASH',
      price: 230,
      category: 'lipsticks',
      image: "ROUGE-COCO-FLASH.avif"
   },
   {
      id: '4',
      name: 'Chanel Chance',
      price: 400,
      category: 'perfumes',
      image: "chance.webp"
   },
   {
      id: '5',
      name: 'Coco Noir',
      price: 650,
      category: 'perfumes',
      image: "coco-noir.webp"
   },
   {
      id: '6',
      name: 'Gabrielle',
      price: 530,
      category: 'perfumes',
      image: "gabrielle.webp"
   },
   {
      id: '7',
      name: 'Mademoiselle',
      price: 480,
      category: 'perfumes',
      image: "mademoiselle.avif"
   },
   {
      id: '8',
      name: 'Chanel N°5',
      price: 800,
      category: 'perfumes',
      image: "n5.webp"
   },
]