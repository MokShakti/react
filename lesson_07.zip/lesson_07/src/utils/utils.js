export const formatPrice = (price) => {
   return `${price} $`;
}